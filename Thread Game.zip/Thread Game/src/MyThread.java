import javax.swing.JOptionPane;


public class MyThread extends Thread{
	private int width = 20 , height = 20;
	private int x,y;
	private java.awt.Graphics g;
	private GameUI UI;
	private boolean isexist = true;
	private MyListener listener;
	private int speed;
	private int x1 = 12 , y1 = 12;
	private long start,end;
	private long last_time;
	private int response;
	private boolean isFinish = true;
	private java.util.ArrayList<MyThread> list;
	private float value = 320;
	private java.awt.Color color = java.awt.Color.blue;
	
	/*
	 * ��д���췽��
	 */
	public MyThread(java.awt.Graphics g,MyListener listener,GameUI UI,int x
			,int y,int speed){
		this.g= g;
		this.UI = UI;
		this.x = x;
		this.y = y;
		this.speed = speed;
		this.listener = listener;
	}
	
	/*
	 * ��дrun�ķ���
	 */
	public void run(){
		drawOval();
	}
	
	public void drawOval(){
		
		start = System.currentTimeMillis();
		while(isFinish){
			synchronized (this.g) {
				g.setColor(java.awt.Color.black);
				g.fillOval(x, y, width, height);
				x += x1;
				y += y1;
				
				getColors();
				g.setColor(color);
				g.fillOval(x, y, width, height);
				
				int x2 = listener.getX();
				if(x>580){
					x1 = -12;
				}
				if(x <10){
					x1 = 12;
				}
				if(y <90){
					y1 = 12;
				}
				if(y>595 && x > x2 && x < x2+100){
					y1 = -12;
				}
				if(y >630){
					if(isexist){
						isAgain();
					}
					stopThread();
				}
				try{
					Thread.sleep(speed);
					value -= 0.1;
				}catch(Exception e){
					e.printStackTrace();
				}
				
				end = System.currentTimeMillis();
				last_time = 100 -(end - start)/1000;
				UI.text_field.setText(last_time + "s");
				UI.pBar.setValue((int)value);
				if (last_time ==0){
					list = UI.list;
					for (int j=0;j<list.size();j++){
						list.get(j).stopThread();
						list.get(j).fadeOval();
					}
					stopThread();
					showDialog();
				}
			}
		}
	}
	public void fadeOval(){
		g.setColor(java.awt.Color.black);  
        g.fillOval(x, y, width, height); 
	}
	
	public void isAgain() {  
        isexist = false;  
        list = UI.list;  
        System.out.println(list.size());  
  
        for (int j = 0; j < list.size(); j++) {  
            // ͣ���̣߳�����ȥ�����һ��Բ  
            list.get(j).stopThread();  
            list.get(j).fadeOval();  
  
        }  
        Object[] options = { "��", "��" };  
        String command = UI.getCommand();  
        response = JOptionPane.showOptionDialog(null,  
                "�����������ˣ���Ҫ����\n��־���ʤ�����Ƿ�����һ�Σ�", null, JOptionPane.YES_OPTION,  
                JOptionPane.NO_OPTION, null, options, null);  
  
        System.out.println(response);  
        if (response == 0) {  
            if (command.equals("��") || command.equals("��ʼ")) {  
                AgainThread();  
                if (list.size() != 0) {  
                    // �ֽ�ԭ���Ķ���Ӷ������Ƴ�  
                    list.removeAll(list);  
                    UI.creatBall(20, 1);  
                }  
  
            }  
            if (command.equals("�е�")) {  
                AgainThread();  
                if (list.size() != 0) {  
                    list.removeAll(list);  
                    UI.creatBall(50, 2);  
                }  
  
            }  
  
            if (command.equals("����")) {  
                AgainThread();  
                if (list.size() != 0) {  
                    list.removeAll(list);  
                    UI.creatBall(40, 2);  
                }  
            }  
        }  
  
        // �������رգ����̶߳���Ӷ������Ƴ�  
        if (response == -1 || response == 1) {  
            list.removeAll(list);  
        }  
  
    }  
  
    /** 
     * ֹͣ�̵߳ķ��� 
     */  
    public void stopThread() {  
        isFinish = false;  
  
    }  
  
    /** 
     * ��ͣ�̵߳ķ��� 
     */  
    public void PauseThread() {  
  
    }  
  
    /** 
     * �����̵߳ķ��� 
     */  
    public void ContinueThread() {  
  
    }  
  
    /** 
     * �Ƿ������ķ��� 
     */  
    public void AgainThread() {  
        isFinish = true;  
  
    }  
  
    public void getColors() {  
  
        if (x % 2 == 0 && y % 2 == 0) {  
            color = java.awt.Color.green;  
        }  
        if (x % 2 == 0 && y % 2 != 0) {  
            color = java.awt.Color.red;  
        }  
        if (x % 2 != 0 && y % 2 != 0) {  
  
            color = java.awt.Color.orange;  
  
        }  
        if (x % 2 != 0 && y % 2 != 0) {  
            color = java.awt.Color.yellow;  
        }  
    }  
  
    public void showDialog() {  
  
        javax.swing.JOptionPane  
                .showInputDialog("�����ģ�������ĸ��֣�\n��ϲ������100s\n���������Ĵ���");  
    }  

}
