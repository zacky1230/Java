import java.awt.event.MouseEvent;


public class MyListener extends java.awt.event.MouseAdapter{
	private java.awt.Graphics g;
	private int x=5,y=620;
	private int width = 100,height = 100;
	
	public MyListener(java.awt.Graphics g){
		this.g=g;
	}
	
	public void mouseMoved(MouseEvent e){
		//���û�����ɫ
		synchronized (this.g){
			g.setColor(java.awt.Color.BLACK);
			g.fillRect(x, y, width, height);
			x = e.getX();
			g.setColor(java.awt.Color.GREEN);
			g.fillRect(x, y, width, height);
		}
	}
	public int getX() {  
        return x;  
    }  
}
